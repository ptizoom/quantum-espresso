! 
! Copyright (C) 2004 WanT Group
! 
! This file is distributed under the terms of the 
! GNU General Public License. See the file `License' 
! in the root directory of the present distribution, 
! or http://www.gnu.org/copyleft/gpl.txt . 
! 
#define  __VERSION_NAME    "WanT"
#define  __VERSION_MAJOR   "2"
#define  __VERSION_MINOR   "3"
#define  __VERSION_PATCH   "0"
#define  __VERSION_LABEL   ""




